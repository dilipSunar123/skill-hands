package com.example.Skill.Hands.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "register_skill_hands")
public class HandsEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    public Long id;
    @Column(name = "name", nullable = false)
    public String name;
    @Column(name = "email", nullable = false)
    public String email;
    @Column(name = "contact_no", nullable = false)
    public String contact;
    @Column(name = "password", nullable = false)
    public String password;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getfName() {
        return name;
    }

    public void setfName(String fName) {
        this.name = fName;
    }

    public String getEmail() {
        return this.email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getContact() {
        return contact;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
