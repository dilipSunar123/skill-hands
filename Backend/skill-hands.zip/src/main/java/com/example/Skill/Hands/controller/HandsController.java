package com.example.Skill.Hands.controller;

import com.example.Skill.Hands.entity.HandsEntity;
import com.example.Skill.Hands.repository.HandsRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;


@RestController
public class HandsController {

    @Autowired
    public HandsRepo repo;

//    @GetMapping("/get/{email}")
//    public List<HandsEntity> findByEmail(@PathVariable String email) {
//        List<HandsEntity> handsEntity = repo.findByEmail(email);
//        System.out.println(email);
//        return handsEntity;
//    }

    @GetMapping("/showDetails")
    public List<HandsEntity> showDetails() {
        return repo.findAll();
    }

    @PostMapping("/addDetails")
    public ResponseEntity addDetails(@RequestBody HandsEntity entity) {
        repo.save(entity);
        return ResponseEntity.ok("done");
    }

    @GetMapping("/get/{id}")
    public HandsEntity getDetailsById(@PathVariable Long id) {
        return repo.findById(id).get();
    }

//    @GetMapping("/get/{email}")
//    public HandsEntity getDetailsByEmail(@PathVariable String email) {
//
//    }

    @PutMapping("/updateDetail/{id}")
    public ResponseEntity<?> updateDetail(@PathVariable Long id, @RequestBody HandsEntity entity) {
        HandsEntity entity1 = repo.findById(id).get();

        if(entity1 != null) {
            entity1.setId(id);
            entity1.setContact(entity.getContact());
            entity1.setPassword(entity.getPassword());
            entity1.setfName(entity.getfName());
            entity1.setEmail(entity.getEmail());
            repo.save(entity1);

            return new ResponseEntity<>("Updated Successfully", HttpStatus.OK);
        } else {
            return new ResponseEntity<>("Not Found", HttpStatus.BAD_REQUEST);
        }
    }

//    @GetMapping("/getGender/{id}")
//    public String getGender(@PathVariable String id) {
//        boolean exists = repo.existsById(Long.parseLong(id));
//
//        if (exists) {
//            HandsEntity entity = new HandsEntity();
//            entity = repo.getById(Long.parseLong(id));
//
//            return entity.getGender();
//        }
//        return "Gender not found";
//    }


    @DeleteMapping("/delete/{id}")
    public ResponseEntity<?> deleteTask(@PathVariable Long id) {
        boolean exists = repo.existsById(id);

        if (exists) {
            repo.deleteById(id);
            return new ResponseEntity<>("Task Deleted Successfully", HttpStatus.OK);
        }
        return new ResponseEntity<>("Something went wrong!", HttpStatus.BAD_REQUEST);
    }
}
