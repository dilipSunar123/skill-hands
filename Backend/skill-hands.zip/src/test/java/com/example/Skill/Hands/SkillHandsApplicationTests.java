package com.example.Skill.Hands;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SkillHandsApplicationTests {

	@Test
	void contextLoads() {
	}

}
